import anndata
import scanpy as sc
import numpy as np
from sklearn.decomposition import PCA as pca
import argparse
from kmeans import KMeans
import matplotlib.pyplot as plt


def parse_args():
    parser = argparse.ArgumentParser(description='number of clusters to find')
    parser.add_argument('--n-clusters', type=int,
                        help='number of features to use in a tree',
                        default=2)
    parser.add_argument('--data', type=str, default='data.csv',
                        help='data path')

    a = parser.parse_args()
    return(a.n_clusters, a.data)

def read_data(data_path):
    return anndata.io.read_csv(data_path)

def preprocess_data(adata: anndata.AnnData, scale :bool=True):
    """Preprocessing dataset: filtering genes/cells, normalization and scaling."""
    sc.pp.filter_cells(adata, min_counts=5000)
    sc.pp.filter_cells(adata, min_genes=500)

    sc.pp.normalize_total(adata, target_sum=1e4)
    adata.raw = adata

    sc.pp.log1p(adata)
    if scale:
        sc.pp.scale(adata, max_value=10, zero_center=True)
        adata.X[np.isnan(adata.X)] = 0

    return adata


def PCA(X, num_components: int):
    return pca(num_components).fit_transform(X)

def main():
    n_classifiers, data_path = parse_args()
    heart = read_data(data_path)
    heart = preprocess_data(heart)
    X = PCA(heart.X, 100)
    # Your code

    kmean_random = KMeans(n_clusters=3, init='random', max_iter=300)
    clustering_with_random_init = kmean_random.fit(X)

    kmean_kmeanspp = KMeans(n_clusters=2, init='kmeans++', max_iter=300)
    clustering_with_kmeans_init = kmean_kmeanspp.fit(X)

    X = PCA(X, 2)

    visualize_cluster(X[:, 0], X[:, 1], clustering_with_random_init)
    visualize_cluster(X[:, 0], X[:, 1], clustering_with_kmeans_init)

def visualize_cluster(x, y, clustering):
    #Your code
    plt.scatter(x, y, c=clustering, cmap='viridis')
    plt.xlabel('PCA Component 1')
    plt.ylabel('PCA Component 2')
    plt.title('KMeans Clustering Visualization')
    plt.colorbar(label='Cluster Label')
    plt.show()

if __name__ == '__main__':
    main()
